namespace Model;

public class Airport
{
    public int idAirport { get; set; }
    public string nameAirport { get; set; }
}