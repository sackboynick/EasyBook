namespace Model;

public class Booking
{
    public int idBooking { get; set; }
    public int flightNO { get; set; }
    public User user { get; set; }
    public int luggage { get; set; }
    public double finalPrice { get; set; }
    public string firstName { get; set; }
    public string lastName { get; set; }
    public string passportId { get; set; }
    public int status { get; set; }
}