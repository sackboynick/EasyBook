namespace Model;

public interface ICompany
{
    Company find();
    List<Company> findAll();
}