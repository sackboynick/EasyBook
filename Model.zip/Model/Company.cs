namespace Model;

[Serializable]
public class Company:MarshalByRefObject
{
    public int idCompany { get; set; }
    public string nameCompany { get; set; }
}