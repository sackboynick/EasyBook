namespace Model;

public class Flight : MarshalByRefObject
{
    public int idFlight { get; set; }
    public int flightNO { get; set; }
    public Airport departureAirport { get; set; }
    public string departureCountry { get; set; }
    public string departureContinent { get; set; }
    public Airport destinationAirport { get; set; }
    public string destinationCountry { get; set; }
    public string destinationContinent { get; set; }
    public DateTime dateTime { get; set; }
    public double length { get; set; }
    public int totalSeats { get; set; }
    public int totalBookedSeats { get; set; }
    public double price { get; set; }
    public double priceForLuggage { get; set; }
    public string status;
}